# fUS-imaging
functional ultrasound (fUS) analysis pipeline for visualizing cerebral blood volume (CBV) changes and correlation

## Setup
### 1. Install Requirements
1. Python 3.8.0
2. numba, numpy, scipy, matplotlib, natsort, h5py

<!-- CONTACT -->
## Author

Stephen Alexander Lee - [@stephenalexlee](https://twitter.com/stephenalexlee) - stephen.alexander.lee@gmail.com

Project Link: [https://github.com/StephenAlexanderLee/fUS-imaging](https://github.com/StephenAlexanderLee/fUS-imaging)

<p align="right">(<a href="#top">back to top</a>)</p>
